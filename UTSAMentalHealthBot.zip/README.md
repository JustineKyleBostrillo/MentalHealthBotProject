AIS PROJECT

UTSA Specialized Mental Health Bot: Creating an interactive AI model which can connect to students on campus struggling with mental health with professionals; as well as give general advice. Both in a physical world and the we world

Installation: 1. Download The Latest Python Version 2. "pip install -e ." In Command Prompt/Terminal 

To Run: "python main.py" In The Root Folder

If You Change The File Names or Directory Names, Make Sure That They Are Also Changed In "config.json". Changing "modules" Name Will Result In A Broken Program; You Have To Edit "main.py."

To Change The AI's Character, Just go to "AIconfig.json" in the dataFiles folder and edit the value of the key "name"

Contributors: Justine Bostrillo, Joshua Martinez, Larry De Los Santos, Nicolas Ly  

